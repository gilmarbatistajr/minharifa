# My Sorteio — pacote de logo

Direção **Bilhete**: container picotado (dois recortes laterais + linha de destaque pontilhada) e nome em serifa editorial.

## Arquivos

| Arquivo | Uso |
|---|---|
| `mysorteio-symbol.svg` | símbolo, fundo claro (tinta + ouro) |
| `mysorteio-symbol-gold.svg` | símbolo, fundo escuro (ouro + tinta) |
| `mysorteio-symbol-mono.svg` | símbolo 1 cor, usa `currentColor` — bordado, carimbo, favicon mono |
| `mysorteio-lockup-horizontal.svg` | lockup padrão com tagline |
| `mysorteio-lockup-horizontal-dark.svg` | lockup sobre fundo escuro |
| `mysorteio-lockup-vertical.svg` | lockup centralizado (splash, impresso) |
| `favicon.svg` | favicon / ícone de app |
| `brand.css` | tokens de cor, tipografia e raio |
| `MySorteioLogo.jsx` | componente React (símbolo + lockup, props `variant`, `size`, `onDark`, `tagline`) |

## Cores

- Tinta noturna `#16181F` — símbolo e texto
- Ouro fosco `#C6A15B` — picote, rótulos, destaque
- Papel `#F0EEE9` — fundo padrão

Ouro é cor de detalhe: não use em texto corrido pequeno sobre papel (contraste insuficiente).

## Tipografia

- **Cormorant Garamond** — nome e títulos (`My` italic 300 + `Sorteio` 600)
- **Jost** 300/400/500 — interface e corpo
- **IBM Plex Mono** — números de bilhete e rótulos com tracking

## Regras

- Margem mínima ao redor do símbolo = raio do recorte (11 un. no viewBox de 100).
- Abaixo de 24 px, reduza o picote para 1 px de espessura.
- Não aplique gradiente, sombra ou outline no símbolo; não estique o lockup; não troque a serifa do nome.

## Integração (Next / React)

```jsx
import MySorteioLogo from '@/components/brand/MySorteioLogo';
import '@/styles/brand.css';

<MySorteioLogo size={40} />              // header claro
<MySorteioLogo size={32} onDark />       // header escuro
<MySorteioLogo variant="symbol" size={28} /> // ícone
```

Os SVGs usam `<text>` com Cormorant Garamond — carregue a fonte via Google Fonts, ou converta o texto em curvas antes de usar os SVGs fora do app.
