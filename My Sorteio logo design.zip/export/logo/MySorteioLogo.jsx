// My Sorteio — logo em React. Sem dependências.
// <MySorteioLogo variant="horizontal" size={44} />

const INK = '#16181F';
const GOLD = '#C6A15B';

export function MySorteioSymbol({ size = 40, bg = INK, dots = GOLD, ...rest }) {
  const id = React.useId ? React.useId() : 'ms-' + Math.random().toString(36).slice(2);
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="My Sorteio" {...rest}>
      <defs>
        <mask id={id}>
          <rect x="0" y="0" width="100" height="100" rx="8" fill="#fff" />
          <circle cx="0" cy="50" r="11" fill="#000" />
          <circle cx="100" cy="50" r="11" fill="#000" />
        </mask>
      </defs>
      <rect x="0" y="0" width="100" height="100" rx="8" fill={bg} mask={`url(#${id})`} />
      <line x1="17" y1="50" x2="83" y2="50" stroke={dots} strokeWidth="2.6" strokeLinecap="round" strokeDasharray="0 6.6" />
    </svg>
  );
}

export function MySorteioLogo({
  variant = 'horizontal',      // 'horizontal' | 'vertical' | 'symbol'
  size = 44,                   // altura do símbolo em px
  tagline = true,
  onDark = false,
}) {
  const ink = onDark ? '#F0EEE9' : INK;
  const symBg = onDark ? GOLD : INK;
  const symDots = onDark ? INK : GOLD;

  if (variant === 'symbol') return <MySorteioSymbol size={size} bg={symBg} dots={symDots} />;

  const vertical = variant === 'vertical';
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: vertical ? 'column' : 'row',
        alignItems: 'center',
        gap: vertical ? size * 0.36 : size * 0.3,
      }}
    >
      <MySorteioSymbol size={size} bg={symBg} dots={symDots} />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: vertical ? 'center' : 'flex-start', gap: size * 0.09 }}>
        <div
          style={{
            fontFamily: "'Cormorant Garamond', Garamond, serif",
            fontSize: size * 0.6,
            lineHeight: 0.95,
            letterSpacing: '-0.015em',
            color: ink,
            whiteSpace: 'nowrap',
          }}
        >
          <span style={{ fontWeight: 300, fontStyle: 'italic' }}>My</span>{' '}
          <span style={{ fontWeight: 600 }}>Sorteio</span>
        </div>
        {tagline && (
          <div
            style={{
              fontFamily: "'IBM Plex Mono', ui-monospace, monospace",
              fontSize: Math.max(8, size * 0.13),
              letterSpacing: '0.3em',
              textTransform: 'uppercase',
              color: GOLD,
            }}
          >
            rifa digital
          </div>
        )}
      </div>
    </div>
  );
}

export default MySorteioLogo;
